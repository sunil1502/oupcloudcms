// normally credentials would not be stored in a file
// accessible directly from the browser.
CONNECTION_CREDENTIALS = {
    "clientKey": "",
    "clientSecret": "",
    "username": "",
    "password": "",
    "baseURL": "/proxy",
    "application": ""
};
