Ext.define('Ext.table.Row', {
    extend: 'Ext.table.Cell',

    xtype: 'tablerow',

    config: {
        baseCls: 'x-table-row',
        defaultType: 'tablecell'
    }
});
